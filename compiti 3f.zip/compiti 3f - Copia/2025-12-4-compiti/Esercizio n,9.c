

#include <stdio.h>

int main()
{
    float limite, tem1, tem2, tem3, media;

    printf("Inserisci il valore limite di accensione: ");
    scanf("%f", &limite);

    printf("Inserisci la temperatura di tre punti dell'edeficio: ");
    scanf("%f", &tem1);
    scanf("%f", &tem2);
    scanf("%f", &tem3);

    media = (tem1 + tem2 + tem3) / 3.0;

    printf("La media delle temperature è: %.2f\n", media);

    if (media < limite) {
        printf("il riscaldamento verra' acceso.\n");
    } else {
        printf("il riscaldamento NON verra' acceso.\n");
    }
    return 0;
}