/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N;
    printf (" inserisci un numero.\n");
    scanf("%d" , &N);
    
    if (N < -5 || N > 10){
        printf(" Il dato è fouri dall'intervallo .\n");
    
    } else { printf(" ok . \n");}
    

    return 0;
}