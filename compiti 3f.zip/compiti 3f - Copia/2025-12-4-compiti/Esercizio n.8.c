/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a, b, c;
    
   	("Inserisci tre numerini:\n ");
   	
	scanf("%d %d %d", &a, &b, &c);

	if ((b - a) == (c - b)) {
		printf("I numeri sono in progressione aritmetica.\n");
	} else {
		printf("I numeri NON sono in progressione aritmetica.\n");
	}

    return 0;
}